<?php session_start(); 
$itemid = $_GET["id"];
$title = $_POST["txtFullName"];
 $image = "uploads/".basename($_FILES["fileImage"]["name"]);
move_uploaded_file($_FILES["fileImage"]["tmp_name"],$image);
					
					
$description = $_POST["txtContact"];
					
	if(isset($_POST["chkBooks"]))
		 { $category = "Books" ;}
if(isset($_POST["chkGames"]))
		 {  $category = "Games" ;}
	if(isset($_POST["chkMovies"]))
		{  $category = "Movies" ;}
					
		if(isset($_POST["chkPublish"]))
		{   $status = 1;  }
		else
			{   $status = 0;  }
					
					
		$con = mysqli_connect("localhost","root","","itemdb"); 
				   
		   if(!$con)
			{
				      die("Cannot connect to DB Server");
			}
					
			$sql = "UPDATE `item` SET `title`='".$title."',`category`='".$category."',`description`='".$description."',`path`='".$image."',`published`='".$status."' WHERE `itemID` = '".$itemid."'" ;
					
		     if(mysqli_query($con,$sql))
			{
				echo "File Updated Sucessfully";
			}
			else
			{
				echo "Something went wrong , Please select the file again !!!!";
			}

            header('Location:myTotebag.php');










?>
