<?php session_start(); 
$itemid = $_GET["id"];
			
$con = mysqli_connect("localhost","root","","itemdb"); 
				   
if(!$con)
	{
		 die("Cannot connect to DB Server");
	}
					
$sql = "DELETE FROM `item` WHERE `itemID` = '".$itemid."'" ;
					
 if(mysqli_query($con,$sql))
	{
		echo "File Deleted";
	}
 else
	{
		echo "Something went wrong , Please select the file again !!!!";
	}

  header('Location:myTotebag.php');

?>
