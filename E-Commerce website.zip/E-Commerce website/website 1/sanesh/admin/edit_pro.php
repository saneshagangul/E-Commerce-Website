<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Products</title>
</head>
<body>
<?php 
if(isset($_GET['pro_id'])){
    $get_id =$_GET['pro_id'];
    
    $con= mysqli_connect("localhost","root","","sgstoredb");
            $get_pro = "select * from monitors where m_id ='$get_id'";
            $run_pro = mysqli_query($con,$get_pro);

            $row_pro=mysqli_fetch_array($run_pro);
                $pro_price= $row_pro['m_price'];
                $pro_id= $row_pro['m_id'];
                $pro_desc= $row_pro['m_desc'];
}
?>
<form action="" method="POST" enctype="multipart/form-data" >
    <table align="center" border="2">
        <tr >
            <td colspan="2" align="center">Edit Monitors</td>
        </tr>
        <tr>
            <td>
                Monitor Desscription
            </td>
            <td>
                <textarea name="m_desc" id="m_desc" cols="20" rows="10"><?php echo $pro_desc; ?></textarea>
            </td>
        </tr>
        <tr>
            <td>Price</td>
            <td><input type="text" name="m_price" id="m_price" value="<?php echo $pro_price; ?>"></td>
        </tr>
        <tr>
                <td >Product Image</td>
                <td><input type="file" name="m_image" id=""></td>
                <td> <img src="product_images/<?php echo $pro_image; ?>" width="60px" height="60px" alt=""></td>
            
        </tr>
        <tr>
            <td colspan="2" align="center"><input type="submit" value="Insert Monitor" name="edit"></td>
        </tr>
    </table>
</form>

<?php
if(isset($_POST['insert'])){
    $pro_price= $_POST['m_price'];
    $pro_desc= $_POST['m_desc'];
    $update_id= $pro_id;
    $con= mysqli_connect("localhost","root","","sgstoredb");
    
    $pro_image = $_FILES['m_image']['name'];
    $pro_image_tmp = $_FILES['m_image']['tmp_name'];

        move_uploaded_file($pro_image_tmp,"product_images/$pro_image");

    $update_product = "update monitors set m_price='$pro_price',
    m_desc='$pro_desc',m_image='$pro_image'
    where m_id='$update_id'";

    $insert_pro=mysqli_query($con,$update_product);
    if($insert_pro){
        echo "<script>alert('product has been updated')</script>";
        echo "<script>window.open('view_products.php','_self')</script>";
    }
    
}

?>


    
</body>
</html>