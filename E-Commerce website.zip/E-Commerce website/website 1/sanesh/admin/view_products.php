<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
</head>
<body>
<table align="center" width="700px" >
        <tr align="center" co>
            <td colspan="6"><h2>View All Products</h2></td>
        </tr>
        <tr align="center">
            <th>Title</th>
            <th>Image</th>
            <th>Price</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php
            $con =mysqli_connect("localhost","root","","sgstoredb");
            $get_pro = "select * from monitors";
            $run_pro = mysqli_query($con,$get_pro);
            
                while($row_pro=mysqli_fetch_array($run_pro)){
            
                    $pro_id =$row_pro['m_id'];
                    $pro_title =$row_pro['m_desc'];
                    $pro_price =$row_pro['m_price'];
                    $pro_image =$row_pro['m_image'];
            
            
        ?>
        <tr align="center">
                <td><?php echo $pro_title;?></td>
                <td><img src="product_images/<?php echo $pro_image;?>" width="60px" height="60px"></td>
                <td><?php echo $pro_price;?></td>
                <td><a href="edit_pro.php?pro_id=<?php echo $pro_id;?>">Edit</a></td>
                <td><a href='delete.php?pro_id=<?php echo $pro_id;?>'>Delete</a></td>
        </tr>
       <?php } ?>
    </table>
</body>
</html>