<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Monitors</title>
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data" >
    <table align="center" border="2">
        <tr >
            <td colspan="2" align="center">Insert Monitors</td>
        </tr>
        <tr>
            <td>
                Monitor Desscription
            </td>
            <td>
                <textarea name="m_desc" id="m_desc" cols="20" rows="10"></textarea>
            </td>
        </tr>
        <tr>
            <td>Price</td>
            <td><input type="text" name="m_price" id="m_price"></td>
        </tr>
        <tr>
                <td >Product Image</td>
                <td><input type="file" name="m_image" id=""></td>
            
        </tr>
        <tr>
            <td colspan="2" align="center"><input type="submit" value="Insert Monitor" name="insert"></td>
        </tr>
    </table>
</form>

<?php
if(isset($_POST['insert'])){
    $m_price= $_POST['m_price'];
    $m_desc= $_POST['m_desc'];
    $con =mysqli_connect("localhost","root","","sgstoredb");
    
    $m_image = $_FILES['m_image']['name'];
    $m_image_tmp = $_FILES['m_image']['tmp_name'];

        move_uploaded_file($m_image_tmp,"product_images/$m_image");

    $insert_product = "insert into monitors (m_price,m_desc,m_image) 
    values ('$m_price','$m_desc','$m_image')";

    $insert_pro=mysqli_query($con,$insert_product);
    if($insert_pro){
        echo "<script>alert('Monitor added')</script>";
        echo "<script>window.open('insert.php','_self')</script>";
    }

}


?>

    
</body>
</html>