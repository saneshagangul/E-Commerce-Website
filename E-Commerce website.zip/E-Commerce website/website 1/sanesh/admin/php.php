<?php
function getMonitor(){


$con =mysqli_connect("localhost","root","","sgstoredb");
$get_pro = "select * from monitors";
$run_pro = mysqli_query($con,$get_pro);

    while($row_pro=mysqli_fetch_array($run_pro)){

        $pro_id =$row_pro['m_id'];
        $pro_title =$row_pro['m_desc'];
        $pro_price =$row_pro['m_price'];
        $pro_image =$row_pro['m_image'];


        echo "
        <div class='column' style='background-color:#aaa;'>
        <center> <img src='admin/product_images/$pro_image' height='150px' width='200px' style='background-color: antiquewhite' /> </center>
        <p align='center'>$pro_title</p> 
        <h3 align='center'> PRICE:RS $pro_price  </h3>    </p>
        <div class='card'> 
              <p align='center'> <button>Add to Cart</button> <button>buy now</button> </p>
              <br>
        </div>               
                            
        
      </div>  



        ";
    }
}

?>
