<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
	* {
  box-sizing: border-box;
}

/* Style the body */
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}
	
	
	/* Header/logo Title */
.header {
	padding: 25px;
	text-align: center;
	background-image: url(images/logo1.jpg);
	background-repeat: no-repeat;
	background-position: left;
	background-size: 300px 300px;
	font-weight: 800;
	font-family: Constantia, "Lucida Bright", "DejaVu Serif", Georgia, serif;
	background-color:antiquewhite;
}

/* Increase the font size of the heading */
 .header h1{
	
    font-size:65px;
	font-family: Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
	font-size: 65px;
	font-style: italic;
	font-weight: 800;
	color: #1E2DD3;
	}

	
		/* Footer */
.footer {
	padding-top: 10px;
	padding-right: 10px;
	padding-left: 10px;
	padding-bottom: 10px;
	text-align: center;
	background-color: antiquewhite;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width: 100%;
  }
}
/*cart button*/
	.card button:hover {
  opacity: 0.7;
}
	
	.card button {
  border: none;
  outline: 0;
  padding: 1px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 33.33%;
  font-size: 18px;
}
	
	.mono{
		background-color:aqua; 
		
	}
	


</style>




</head>

<body>
<div class="header">
     <h1>SG COMPUTER SOLUTIONS</h1>
</div>


<div class="mono">
<h2 align="center">MONITORS</h2>
</div>


<div class="row">
    <?php  getMonitor()
  ?> 
    
  
</div>
<?php

$con = mysqli_connect("localhost","root","","sgstoredb");
			if(!$con)
			{	
				die("Cannot upload the file, Please choose another file");		
			}
			$sql = "DELETE FROM `monitors` WHERE `m_id` = ".$_GET["pro_id"];
	   
	  	mysqli_query($con,$sql);	
		header('Location:index.html');
	

	?>







<div class="footer">
  <table width="100%" height="100" border="1" cellspacing="2" cellpadding="5">
    <tbody>
      <tr>
        <td><left> <img src="images/logo1.jpg"  width="150" height="150"><span style="font-size: 18px; color: #2819E9;"><strong>SG COMPUTER SOLUTION <br>
          Address:87/2/B Weerarathna Mawatha Ragama Walpola <br>
          Hotline:0722000574 <br>
          Service Email:saneshagangul@gmail.com <br>
          <span style="color: #F3185C">IT19084428 </span></strong></span></left></td>
        <th scope="col"> <h1> Information </h1>
          <br>
          About Us <br>
          Contact <br>
          Terms & Conditions <br>
          Privacy </th>
        <th scope="col">  <br>
          <br>
          <br>
          <br>
        <h1>  Follow Us </h1>
          <br>
          <a href="www.facebook.com"> <img width="60" height="60" src="images/facebook.png" title="facebook" alt="facebook"/></a> <br>
          <a href="www.twitter.com"> <img width="60" height="60" src="images/twitter.png" title="twitter" alt="twitter"/></a> <br>
          <a href="www.youtube.com"> <img width="60" height="60" src="images/youtube.png" title="youtube" alt="youtube"/></a></th>
      </tr>
    </tbody>
  </table>
</div>




</body>
</html>