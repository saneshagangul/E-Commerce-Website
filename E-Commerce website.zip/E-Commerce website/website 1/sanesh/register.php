<?php session_start(); ?>

<?php
if(isset($_POST["btnRegister"]))
{
    $fname = $_POST["txtfname"];
    $lname = $_POST["txtlname"];
    $contact = $_POST["txtContact"];
    $email = $_POST["email"];
    $address = $_POST["address"];
    $pass = $_POST["txtPassword"];


    $con = mysqli_connect("localhost:3306","root","","sgstoredb");
        if (!$con)
        {
            die("cannot connect to DB server");
        }

      //  $sql = "INSERT INTO `customer` (`cust_ID`, `first_Name`, `last_Name`, `cust_DOB`, `cust_NIC`, `cust_Email`, `cust_Address`, `cust_City`, `cust_Zip`, `cust_Pass`) VALUES (NULL, '".$fname."', '".$lname."', '".$dob."', '".$nic."', '".$email."', '".$address."', '".$city."', '".$zip."', '".$pass."');";
      $sql = "INSERT INTO `tbl_user2` (`first_name`, `last_name`, `email`, `address`, `contact_no`, `password`) VALUES ('".$fname."', '".$lname."', '".$email."','".$address."','".$contact."','".$pass."');";

        mysqli_query($con,$sql);

        mysqli_close($con);
        echo '<script language="javascript">';
        echo 'alert("Registration Successful !\n Please Signin to continue")';
        echo '</script>';
        header('Location:login.html');

}
?>