<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<?php
 
include_once('connection.php');
  
function test_input($data) {
     
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
  
if ($_SERVER["REQUEST_METHOD"]== "POST") {
     
    $admin_email = test_input($_POST["admin_email"]);
    $admin_pw = test_input($_POST["admin_pw"]);
    $stmt = $conn->prepare("SELECT * FROM admin WHERE admin_email = '$admin_email' AND admin_pw = '$admin_pw'");
    $stmt->execute();
    $users = $stmt->fetchAll();
     
	$flag = TRUE;
	
    foreach($users as $user) {
		$flag = FALSE;
		 header("Location: admin.html");
         /*
        if(($user['admin_email'] == $admin_email) &&
            ($user['admin_pw'] == $admin_pw)) {
                header("Location: admin1.php");
        }
        else {
            echo "<script language='javascript'>";
            echo "alert('WRONG INFORMATION')";
            echo "</script>";
            die();
        }
		*/
		
		
    }
	
	if($flag){
		 echo "<script language='javascript'>";
            echo "alert('WRONG INFORMATION')";
            echo "</script>";
            die();
	}
}
 
?>


</body>
</html>