-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2021 at 12:03 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sgstoredb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(100) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pw` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `monitors`
--

CREATE TABLE `monitors` (
  `m_id` int(11) NOT NULL,
  `m_desc` varchar(255) NOT NULL,
  `m_price` int(255) NOT NULL,
  `m_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `monitors`
--

INSERT INTO `monitors` (`m_id`, `m_desc`, `m_price`, `m_image`) VALUES
(4, 'awqs', 200, 'acer.jpg'),
(5, 'qwerr', 300, 'Mo7.jpg'),
(6, '4gb ram', 500, 'mo3.png'),
(7, 'msi wert', 123000, 'Mo6.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `id` int(5) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `created_user` int(5) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`id`, `brand_name`, `created_user`, `created_datetime`) VALUES
(1, 'MSI', 1, '2021-02-04 13:47:23'),
(2, 'HP', 1, '2021-02-04 13:47:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(5) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `description` varchar(300) NOT NULL,
  `status_code` varchar(10) DEFAULT 'ACTIVE',
  `created_user` int(5) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `contactno` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `Name`, `contactno`, `email`, `message`) VALUES
(1, 'test', 'test', 'test', 'test'),
(2, 'sanesh sanesh', 'saneshsanesh', 'saneshsanesh', 'saneshsanesh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login_history`
--

CREATE TABLE `tbl_login_history` (
  `id` int(5) NOT NULL,
  `username` varchar(200) NOT NULL,
  `login_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(5) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `member_id` int(5) NOT NULL,
  `delivery_address` varchar(300) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `status_code` varchar(50) NOT NULL,
  `delivery_fee` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_item`
--

CREATE TABLE `tbl_order_item` (
  `id` int(5) NOT NULL,
  `order_id` int(5) NOT NULL,
  `product_id` int(5) NOT NULL,
  `qty` int(5) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(5) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `brand_id` int(5) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int(5) NOT NULL,
  `status_code` varchar(10) NOT NULL,
  `created_user` int(5) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_user` int(5) NOT NULL,
  `updated_datetime` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `product_name`, `brand_id`, `description`, `price`, `category_id`, `status_code`, `created_user`, `created_datetime`, `updated_user`, `updated_datetime`) VALUES
(1, 'msi-GI76', 1, 'core i7\r\n512 SSD\r\n4GB RAM\r\n4GB VGA', '999.99', 0, 'ACTIVE', 1, '2021-02-04 13:43:32', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_image`
--

CREATE TABLE `tbl_product_image` (
  `id` int(5) NOT NULL,
  `product_id` int(5) NOT NULL,
  `image_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product_image`
--

INSERT INTO `tbl_product_image` (`id`, `product_id`, `image_name`) VALUES
(1, 1, 'msi_laptop.jpg'),
(2, 1, 'msi_500.jpg'),
(3, 2, 'hp_lap_300.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_review`
--

CREATE TABLE `tbl_review` (
  `id` int(5) NOT NULL,
  `product_id` int(5) NOT NULL,
  `comment` text NOT NULL,
  `rate` int(5) NOT NULL,
  `created_user` int(5) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `contact_no` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pword` text NOT NULL,
  `role_code` varchar(30) NOT NULL,
  `status_code` varchar(20) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `first_name`, `last_name`, `email`, `address`, `contact_no`, `username`, `pword`, `role_code`, `status_code`, `created_datetime`) VALUES
(1, 'Sanesh', 'Gangul', 'sana@gmail.com', 'Ragama', 715866470, 'sana', '*667F407DE7C6AD07358FA38DAED7828A72014B4E', 'ADMIN', 'ACTIVE', '2021-02-14 14:33:09'),
(2, 'Hi', 'Hello', 'r@gmail.com', 'Seeduwa', 123456, 'rrrr', '*6BB4837EB74329105EE4568DDA7DC67ED2CA2AD9', 'MEMBER', 'ACTIVE', '2021-03-02 14:52:12'),
(3, 'Kushan', 'Perera', 'kush@gmail.com', 'Raddoluwa', 785455470, 'kush', '*23AE809DDACAF96AF0FD78ED04B6A265E05AA257', 'MEMBER', 'ACTIVE', '2021-03-02 16:04:32'),
(4, 'kusum', 'silwa', 'silva@gmail.com', 'Ragama', 863255471, 'silva', '*23AE809DDACAF96AF0FD78ED04B6A265E05AA257', 'MEMBER', 'ACTIVE', '2021-03-02 16:08:45'),
(5, 'as', 'abc', 'qwe', 'asdf', 123, 'san', 'qwer', 'member', 'active', '2021-04-26 10:10:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user2`
--

CREATE TABLE `tbl_user2` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact_no` varchar(12) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user2`
--

INSERT INTO `tbl_user2` (`id`, `first_name`, `last_name`, `email`, `address`, `contact_no`, `password`) VALUES
(1, 'test', 'test', 'test', 'test', 'test', 'test'),
(2, 'test2', 'test2', 'test2', 'test2', 'test2', 'test2'),
(3, 'test3', 'test3', 'test3', 'test3', 'test3', 'test3'),
(4, 'sanesh', 'sanesh', 'sanesh', 'sanesh', 'sanesh', 'sanesh'),
(5, 'sawd', 'wse', 'saneshagangul@gmail.com', 'qwer', 'awqed', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `monitors`
--
ALTER TABLE `monitors`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_login_history`
--
ALTER TABLE `tbl_login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product_image`
--
ALTER TABLE `tbl_product_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_review`
--
ALTER TABLE `tbl_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user2`
--
ALTER TABLE `tbl_user2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `monitors`
--
ALTER TABLE `monitors`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_login_history`
--
ALTER TABLE `tbl_login_history`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_product_image`
--
ALTER TABLE `tbl_product_image`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_review`
--
ALTER TABLE `tbl_review`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_user2`
--
ALTER TABLE `tbl_user2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
