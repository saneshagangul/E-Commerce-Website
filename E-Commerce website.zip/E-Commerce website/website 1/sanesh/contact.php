<?php session_start(); ?>

<?php
if(isset($_POST["btnContact"]))
{
    $name = $_POST["txtname"];
    $phone = $_POST["txtphone"];
    $email = $_POST["txtemail"];
    $message = $_POST["txtmessage"];



    $con = mysqli_connect("localhost","root","","sgstoredb");
        if (!$con)
        {
            die("cannot connect to DB server");
        }


      $sql = "INSERT INTO `tbl_contact` (`Name`, `contactno`, `email`, `message`) VALUES ('".$name."', '".$phone."', '".$email."','".$message."');";

        mysqli_query($con,$sql);

        mysqli_close($con);
        echo '<script language="javascript">';
        echo 'alert("Registration Successful !\n Please Signin to continue")';
        echo '</script>';
        header('Location:index.html');

}
?>