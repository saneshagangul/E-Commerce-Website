<?php session_start(); ?>

<?php
    if(isset($_POST["btnLogin"]))
    {
            $email = $_POST["txtemail"];
            $password = $_POST["txtpsw"];
    
            $con = mysqli_connect("localhost","root","","sgstoredb");
            if (!$con) {
            die("cannot connect to DB server");
            }
    
            $sql = "SELECT * FROM `tbl_user2` WHERE `email`='".$email."' AND `password` = '".$password."'";
    
            $result = mysqli_query($con,$sql);
    
            if(mysqli_num_rows($result)>0)
            {
            //$_SESSION["userEmail"] = $email;
            header('Location:index.html');
            }
            else
            {
                echo '<script language="javascript">';
                echo 'alert("Please enter valid username and password.")';
                echo '</script>';
                header('Location:signup.html');
            }
    }
?>